from src.masks import get_mask_account

"""Тест функции маскировки номера банковского счета"""

print(get_mask_account(str(73654108430135874305)))
