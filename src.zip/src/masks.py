def get_mask_card_number(card_number):
    """Функция маскировки номера банковской карты"""

    return int(card_number[:6] + (len(card_number) - 10) * "*" + card_number[-4:])


def get_mask_account(account):
    """Функция маскировки номера банковского счета"""

    return "**" + account[-4:]
