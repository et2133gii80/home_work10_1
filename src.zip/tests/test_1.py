from src.masks import get_mask_card_number

"""Тест функции маскировки номера банковской карты"""

print(get_mask_card_number(str(7000792289606361)))
